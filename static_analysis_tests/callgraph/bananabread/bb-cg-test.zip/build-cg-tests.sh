#!/bin/bash

wasm-opt bb.wasm --print-call-graph-edges > static_cg_edges.csv
wasabi --hooks=call bb.wasm
mv out/bb.wasabi.js .
mv bb.wasm bb_original.wasm
mv out/bb.wasm ./bb.wasm